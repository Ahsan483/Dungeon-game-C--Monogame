﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame;
using System;
using System.Globalization;
namespace Dungeon_Game
{
    public class Game1 : Game 
    {
        private float elapsedTime = 0f;
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        Texture2D player;
        Vector2 playerposition;
        float playerspeed;
        Texture2D background;
        bool gamestart = false;
        bool validmove = false;
        Texture2D portal;
        Vector2 portalpos;
        Texture2D[] heart;
        Texture2D[] treasure;
        Texture2D[] enemy;
        Vector2[] treasureposition;
        Vector2[] enemyposition;
        Vector2[] heartposition;
        bool win = false;
        SpriteFont score;
        int pscore=0;
        int health = 3;
        string scoretxt;
        string healthtxt;
        bool leftmoving = false;
        bool rightmoving = false;
        bool upmoving = false;
        bool downmoving = false;

        private Random random = new Random();
        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            treasure = new Texture2D[3];
            enemy = new Texture2D[3];
            heart = new Texture2D[3];

            heartposition = new Vector2[3];
            treasureposition = new Vector2[3];
            enemyposition = new Vector2[3];
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            //player
            
            playerposition = new Vector2(500, -200);
            playerspeed = 40f;
            // portalposition
            portalpos = new Vector2(-210, -200);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            player = Content.Load<Texture2D>("pl");
            background = Content.Load<Texture2D>("d1");
            portal = Content.Load<Texture2D>("portal");
            score = Content.Load<SpriteFont>("Arial");
            
            //load treasure
            for (int i = 0; i < 3; i++)
            {
                if (i == 0)
                {
                    treasure[i] = Content.Load<Texture2D>("treasure");
                    treasureposition[i] = new Vector2(
                        random.Next(-90, 60),
                        random.Next(-200, -47)
                        );

                    enemy[i] = Content.Load<Texture2D>("enemy");
                    enemyposition[i] = new Vector2(
                        random.Next(-90,60),
                        random.Next(-200, -47)
                        );


                    heart[i] = Content.Load<Texture2D>("heart");
                    heartposition[i] = new Vector2(
                        random.Next(-90, 60),
                        random.Next(-200, -47)
                        );
                }
                
                if (i == 1)
                {
                    treasure[i] = Content.Load<Texture2D>("treasure");
                    treasureposition[i] = new Vector2(
                        random.Next(-207, -51),
                        random.Next(46, 220)
                        );

                    enemy[i] = Content.Load<Texture2D>("enemy");
                    enemyposition[i] = new Vector2(
                        random.Next(-207, -51),
                        random.Next(46, 220)
                        );

                    heart[i] = Content.Load<Texture2D>("heart");
                    heartposition[i] = new Vector2(
                        random.Next(-207, -51),
                        random.Next(46, 220)
                        );
                }
                if(i == 2)
                {
                    treasure[i] = Content.Load<Texture2D>("treasure");
                    treasureposition[i] = new Vector2(
                        random.Next(76, 324),
                        random.Next(58, 220)
                        );

                    enemy[i] = Content.Load<Texture2D>("enemy");
                    enemyposition[i] = new Vector2(
                        random.Next(76, 324),
                        random.Next(58, 220)
                        );

                    heart[i] = Content.Load<Texture2D>("heart");
                    heartposition[i] = new Vector2(
                        random.Next(76, 324),
                        random.Next(58, 220)
                        );

                }
            }


        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();


            // Increment elapsed time
            elapsedTime += (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (elapsedTime >= 5f)
            {
                // Update enemy positions
                for (int i = 0; i < 3; i++)
                {
                    if (i == 0)
                    {

                        enemy[i] = Content.Load<Texture2D>("enemy");
                        enemyposition[i] = new Vector2(
                            random.Next(-90, 60),
                            random.Next(-200, -47)
                            );


                    }

                    if (i == 1)
                    {

                        enemy[i] = Content.Load<Texture2D>("enemy");
                        enemyposition[i] = new Vector2(
                            random.Next(-207, -51),
                            random.Next(46, 220)
                            );

                    }
                    if (i == 2)
                    {
                        
                        enemy[i] = Content.Load<Texture2D>("enemy");
                        enemyposition[i] = new Vector2(
                            random.Next(76, 324),
                            random.Next(58, 220)
                            );

                    }
                }

                // Reset elapsed time
                elapsedTime = 0f;
            }

            // TODO: Add your update logic here

            //mouse
            var mousestate = Mouse.GetState();
            if(mousestate.LeftButton == ButtonState.Pressed)
            {
                background = Content.Load<Texture2D>("s3");
                gamestart = true;
            }

            //keyboard
            var kstate = Keyboard.GetState();

            if (playerposition.X <= 540 && playerposition.X >= -230
                && playerposition.Y >= -220 && playerposition.Y <= 235)
            {



                if (playerposition.X > 69 && playerposition.X < 196
                    && playerposition.Y > -232 && playerposition.Y < -15 ||
                    playerposition.X > -187 && playerposition.X < -111
                    && playerposition.Y > -240 && playerposition.Y < 34 ||
                    playerposition.X > -39 && playerposition.X < 34
                    && playerposition.Y > -17 && playerposition.Y < 252 ||
                    playerposition.X > 336 && playerposition.X < 566
                    && playerposition.Y > -53 && playerposition.Y < 136

                )

                {
                    validmove = false;
                    if (leftmoving)
                    {
                        playerposition.X += 1;
                    }
                    if (rightmoving)
                    {
                        playerposition.X -= 1;
                    }
                    if (upmoving)
                    {
                        playerposition.Y += 1;
                    }
                    if (downmoving)
                    {
                        playerposition.Y -= 1;
                    }

                }
                else
                {
                    validmove = true;
                }
            }

            else
            {
                validmove = false;
                if (leftmoving)
                {
                    playerposition.X += 1;
                }
                if (rightmoving)
                {
                    playerposition.X -= 1;
                }
                if (upmoving)
                {
                    playerposition.Y += 1;
                }
                if (downmoving)
                {
                    playerposition.Y -= 1;
                }
            }

            if (gamestart && validmove)
            {
                if (kstate.IsKeyDown(Keys.Up))
                {

                    leftmoving = false;
                    rightmoving = false;
                    upmoving = true;
                    downmoving = false;
                    playerposition.Y -= playerspeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                }

                if (kstate.IsKeyDown(Keys.Down))
                {

                    leftmoving = false;
                    rightmoving = false;
                    upmoving = false;
                    downmoving = true;
                    playerposition.Y += playerspeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                }

                if (kstate.IsKeyDown(Keys.Left))
                {

                    leftmoving = true;
                    rightmoving = false;
                    upmoving = false;
                    downmoving = false;
                    playerposition.X -= playerspeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                }

                if (kstate.IsKeyDown(Keys.Right))
                {

                    leftmoving = false;
                    rightmoving = true;
                    upmoving = false;
                    downmoving = false;
                    playerposition.X += playerspeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
                }
            }


            // Check for collisions with treasures and enemies
            for (int i = 0; i < 3; i++)
            {
                // Check collision with treasure
                if (Vector2.Distance(playerposition, treasureposition[i]) < 30)
                {
                    pscore += 10;
                    // Hide the treasure
                    treasureposition[i] = new Vector2(-1000, -1000); // Move it off-screen
                }

                // Check collision with enemy
                if (Vector2.Distance(playerposition, enemyposition[i]) < 30)
                {
                    health -= 1;
                    // Move the player back to the original position
                    playerposition = new Vector2(500, -200);
                }

                // Check collision with heart
                if (Vector2.Distance(playerposition, heartposition[i]) < 30)
                {
                    health += 1;
                    //hide 

                    heartposition[i] = new Vector2(-1000, -1000); // Move it off-screen
                }


                // Check collision with portal
                if (Vector2.Distance(playerposition, portalpos) < 30 && win)
                {

                    background = Content.Load<Texture2D>("d2");
                }
            }

            scoretxt = "Score : " + pscore.ToString();
            healthtxt = "Health : " + health.ToString();

            if(pscore == 30)
            {
                win = true;

            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            //player drawing

            // Calculate scaling factor
            float scaleX = (float)_graphics.PreferredBackBufferWidth / background.Width;
            float scaleY = (float)_graphics.PreferredBackBufferHeight / background.Height;
            float scale = Math.Max(scaleX, scaleY);

            // Calculate scaled dimensions
            int width = (int)(background.Width * scale);
            int height = (int)(background.Height * scale);

            // Draw background


            _spriteBatch.Begin();
            _spriteBatch.Draw(background, new Rectangle(0, 0, width, height), Color.White);
            _spriteBatch.End();
            //Draw player
            if (gamestart)
            {
                _spriteBatch.Begin();

                for (int i = 0; i < 3; i++)
                {
                    _spriteBatch.Draw(treasure[i], treasureposition[i], Color.White);
                    _spriteBatch.Draw(enemy[i], enemyposition[i], Color.White);
                    _spriteBatch.Draw(heart[i], heartposition[i], Color.White);

                }
                _spriteBatch.Draw(portal, portalpos, Color.White);
                _spriteBatch.Draw(player, playerposition, Color.White);
                _spriteBatch.DrawString(score, scoretxt, new Vector2(10, 10), Color.Red);
                _spriteBatch.DrawString(score, healthtxt, new Vector2(200, 10), Color.Green);

                _spriteBatch.End();
            }
            base.Draw(gameTime);
        }
    }
}
