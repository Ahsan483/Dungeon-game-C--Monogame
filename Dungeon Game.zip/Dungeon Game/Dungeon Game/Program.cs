﻿
using var game = new Dungeon_Game.Game1();
game.Run();
